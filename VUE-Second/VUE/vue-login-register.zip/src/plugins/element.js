import Vue from 'vue'
import element from 'element-ui'

Vue.use(element)
